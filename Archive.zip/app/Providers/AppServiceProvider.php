<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use App\Enums\Role;
use App\Models\User;
use Illuminate\Support\Facades\Gate;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Gate::define('record-payments', fn(User $u) =>
        $u->hasAnyRole([Role::Admin, Role::Receptionist]));

        Gate::define('manage-maintenance', fn(User $u) =>
        $u->hasAnyRole([Role::Admin, Role::Coordinator]));
    }
}

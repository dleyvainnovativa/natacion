<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class SlotRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('move-classes') ?? false;
    }

    public function rules(): array
    {
        return [
            'month'         => ['nullable', 'regex:/^\d{4}-\d{2}$/'],
            'program_id'    => ['required', 'exists:programs,id'],
            'level_id'       => ['nullable', 'exists:program_levels,id'],
            'instructor_id'   => ['nullable', 'exists:instructors,id'],
            'instructor_id_2' => ['nullable', 'exists:instructors,id', 'different:instructor_id'],
            'lane_id'       => ['nullable', 'exists:lanes,id'],
            'weekday'       => ['required', 'integer', 'between:1,7'],
            'start_time'    => ['required', 'date_format:H:i'],
            'duration_min'  => ['nullable', 'integer', 'min:5', 'max:240'],

            // Roster inicial elegido en el modal (opcional).
            'member_ids'    => ['nullable', 'array'],
            'member_ids.*'  => ['integer', 'exists:members,id'],
        ];
    }

    public function messages(): array
    {
        return [
            'program_id.required' => 'Elige un programa.',
            'weekday.required'    => 'Elige un día.',
            'start_time.required' => 'Indica la hora de inicio.',
            'start_time.date_format' => 'La hora debe tener formato HH:MM.',
        ];
    }
}

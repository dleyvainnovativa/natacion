/**
 * Swim Fitness — helpers JS centralizados.
 * Vanilla JS. Importar funciones donde se necesiten en vez de repetir fetch.
 */

import './bootstrap-theme';

const csrf = () =>
    document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ?? '';

const baseHeaders = () => ({
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'X-CSRF-TOKEN': csrf(),
    'X-Requested-With': 'XMLHttpRequest',
});

/** Núcleo de peticiones. Lanza en respuestas no OK con el body parseado. */
async function request(url, method, body = null) {
    const opts = { method, headers: baseHeaders() };
    if (body !== null) opts.body = JSON.stringify(body);

    const res = await fetch(url, opts);
    const data = await res.json().catch(() => ({}));

    if (!res.ok) {
        const err = new Error(data.message || 'Error en la solicitud');
        err.status = res.status;
        err.data = data;
        throw err;
    }
    return data;
}

export const http = {
    get:    (url)        => request(url, 'GET'),
    post:   (url, body)  => request(url, 'POST', body),
    put:    (url, body)  => request(url, 'PUT', body),
    delete: (url)        => request(url, 'DELETE'),
};

/** Notificaciones tipo toast (contenedor #toast-root en el layout). */
export function toast(message, type = 'success') {
    const root = document.getElementById('toast-root');
    if (!root) return;

    const el = document.createElement('div');
    el.className = `toast-item toast-${type}`;
    el.setAttribute('role', 'status');
    el.textContent = message;
    root.appendChild(el);

    requestAnimationFrame(() => el.classList.add('show'));
    setTimeout(() => {
        el.classList.remove('show');
        setTimeout(() => el.remove(), 250);
    }, 3200);
}

/** Estado de carga en un botón (deshabilita + spinner). */
export function setLoading(btn, loading, labelWhenDone) {
    if (!btn) return;
    if (loading) {
        btn.dataset.originalLabel = btn.innerHTML;
        btn.disabled = true;
        btn.innerHTML =
            '<span class="spinner-border spinner-border-sm me-2"></span>Cargando…';
    } else {
        btn.disabled = false;
        btn.innerHTML = labelWhenDone ?? btn.dataset.originalLabel ?? btn.innerHTML;
    }
}

/** Serializa un <form> a objeto plano (sin usar <form> submit nativo). */
export function serializeForm(form) {
    const out = {};
    new FormData(form).forEach((value, key) => {
        if (key.endsWith('[]')) {
            const k = key.slice(0, -2);
            (out[k] ??= []).push(value);
        } else {
            out[key] = value;
        }
    });
    return out;
}

/** Helper de modal Bootstrap por id. */
export const modal = {
    show(id) { return bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).show(); },
    hide(id) { return bootstrap.Modal.getOrCreateInstance(document.getElementById(id)).hide(); },
};

// Exponer en window para scripts inline puntuales de Blade.
window.SF = { http, toast, setLoading, serializeForm, modal };

/* ==================================================================
 * TIER 2 — Horario. Pegar al final de resources/js/app.js
 * (usa http, toast, modal ya definidos arriba en este archivo)
 * ================================================================== */

let activeSessionId = null;

/** Abre el modal de mover con los datos de la tarjeta clickeada. */
function openMove(cardEl) {
    activeSessionId = cardEl.dataset.sessionId;

    const startsInput = document.getElementById('move-starts');
    startsInput.value = cardEl.dataset.starts || '';

    document.getElementById('move-lane').value = cardEl.dataset.lane || '';
    document.getElementById('move-instructor').value = cardEl.dataset.instructor || '';
    // "Sin cambio" por defecto; el co-maestro actual se usa en el servidor si no se toca.
    const i2 = document.getElementById('move-instructor-2');
    if (i2) i2.value = '';
    document.getElementById('move-notes').value = '';
    document.getElementById('move-warnings').innerHTML = '';
    document.getElementById('scope-date').checked = true;

    // Previsualizar conflictos cuando cambian fecha/carril/instructor.
    ['move-starts', 'move-lane', 'move-instructor'].forEach((id) => {
        document.getElementById(id).onchange = previewConflicts;
    });

    modal.show('moveModal');
}

async function previewConflicts() {
    if (!activeSessionId) return;
    const payload = collectMovePayload();
    try {
        const res = await http.post(`/horario/sesiones/${activeSessionId}/conflictos`, payload);
        renderWarnings(res.warnings || []);
    } catch (e) {
        // Silencioso: la previsualización no debe estorbar.
    }
}

function collectMovePayload() {
    return {
        starts_at: document.getElementById('move-starts').value,
        lane_id: document.getElementById('move-lane').value || null,
        instructor_id: document.getElementById('move-instructor').value || null,
    };
}

function renderWarnings(warnings) {
    const box = document.getElementById('move-warnings');
    if (!warnings.length) { box.innerHTML = ''; return; }
    box.innerHTML =
        '<div class="alert alert-warning py-2 small"><strong>Avisos:</strong><ul class="mb-0">' +
        warnings.map((w) => `<li>${w}</li>`).join('') +
        '</ul></div>';
}

async function submitMove() {
    if (!activeSessionId) return;
    const scope = document.querySelector('input[name="move-scope"]:checked')?.value || 'date';
    // '' = sin cambio (no se envía); '0' = quitar co-maestro; id = asignar.
    const i2 = document.getElementById('move-instructor-2')?.value ?? '';
    const payload = {
        ...collectMovePayload(),
        scope,
        notes: document.getElementById('move-notes').value || null,
    };
    if (i2 !== '') payload.instructor_id_2 = i2;
    try {
        const res = await http.post(`/horario/sesiones/${activeSessionId}/mover`, payload);
        renderWarnings(res.warnings || []);
        toast(res.message || 'Clase movida.');
        setTimeout(() => location.reload(), 700);
    } catch (e) {
        toast(e.data?.message || 'No se pudo mover la clase.', 'error');
    }
}

async function cancelSession() {
    if (!activeSessionId) return;
    if (!confirm('¿Cancelar esta clase?')) return;
    const notes = document.getElementById('move-notes').value || null;
    try {
        const res = await http.post(`/horario/sesiones/${activeSessionId}/cancelar`, { notes });
        toast(res.message || 'Clase cancelada.');
        setTimeout(() => location.reload(), 700);
    } catch (e) {
        toast('No se pudo cancelar.', 'error');
    }
}

/** Filtro de lista simple (roster). */
function filterList(input, itemSelector) {
    const term = input.value.trim().toLowerCase();
    document.querySelectorAll(itemSelector).forEach((el) => {
        const text = el.dataset.text || el.textContent.toLowerCase();
        el.style.display = text.includes(term) ? '' : 'none';
    });
}

// Exponer en el objeto global SF (definido arriba en app.js).
Object.assign(window.SF, {
    openMove, submitMove, cancelSession, filterList,
});

/* ==================================================================
 * TIER 3 — Asistencia. Pegar al final de resources/js/app.js
 * ================================================================== */

/**
 * Guarda la asistencia de un instructor desde la fila de la tabla. Lee estado
 * y suplente de los selects de la misma fila, hace POST y refleja el resultado
 * (quién impartió) sin recargar.
 */
async function saveInstructorAttendance(btn) {
    const row = btn.closest('tr[data-session]');
    const sessionId = row.dataset.session;
    const status = row.querySelector('.att-status').value;
    const substitute = row.querySelector('.att-sub').value || null;

    // Regla de UI: si es "puntual" no tiene sentido un suplente.
    const payload = {
        status,
        substitute_id: status === 'on_time' ? null : substitute,
    };

    SF.setLoading(btn, true);
    try {
        const res = await SF.http.post(`/asistencia/instructores/${sessionId}`, payload);
        row.querySelector('.att-actual').textContent = res.actual_instructor || '—';

        if (res.warnings && res.warnings.length) {
            res.warnings.forEach((w) => SF.toast(w, 'error'));
        }
        SF.toast(res.message || 'Guardado.');
    } catch (e) {
        SF.toast(e.data?.message || 'No se pudo guardar.', 'error');
    } finally {
        SF.setLoading(btn, false, 'Guardar');
    }
}

Object.assign(window.SF, { saveInstructorAttendance });


function initScheduleDnD() {
    // Solo desktop: si el ancho es de móvil, no activar DnD.
    if (window.matchMedia('(max-width: 991.98px)').matches) return;

    const cards = document.querySelectorAll('.session-card[data-session-id]');
    const columns = document.querySelectorAll('.schedule-col[data-date]');
    if (!cards.length || !columns.length) return;

    let draggedCard = null;

    cards.forEach((card) => {
        card.setAttribute('draggable', 'true');

        card.addEventListener('dragstart', (e) => {
            draggedCard = card;
            card.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            // Necesario en Firefox para iniciar el drag.
            e.dataTransfer.setData('text/plain', card.dataset.sessionId);
        });

        card.addEventListener('dragend', () => {
            card.classList.remove('dragging');
            columns.forEach((c) => c.classList.remove('drop-target'));
            draggedCard = null;
        });
    });

    columns.forEach((col) => {
        col.addEventListener('dragover', (e) => {
            e.preventDefault(); // permite soltar
            e.dataTransfer.dropEffect = 'move';
            col.classList.add('drop-target');
        });

        col.addEventListener('dragleave', () => col.classList.remove('drop-target'));

        col.addEventListener('drop', (e) => {
            e.preventDefault();
            col.classList.remove('drop-target');
            if (!draggedCard) return;

            const targetDate = col.dataset.date;           // Y-m-d
            const originalStarts = draggedCard.dataset.starts; // Y-m-dTH:i
            const originalTime = originalStarts.includes('T')
                ? originalStarts.split('T')[1]
                : '00:00';

            // Si soltó en el mismo día, no hacer nada.
            const originalDate = originalStarts.split('T')[0];
            if (originalDate === targetDate) return;

            // Abrir el modal existente precargado con el nuevo día + hora original.
            SF.openMove(draggedCard);
            const startsInput = document.getElementById('move-starts');
            if (startsInput) {
                startsInput.value = `${targetDate}T${originalTime}`;
                // Disparar la previsualización de conflictos.
                startsInput.dispatchEvent(new Event('change'));
            }
        });
    });
}

document.addEventListener('DOMContentLoaded', initScheduleDnD);


/* ==================================================================
 * BUNDLE B — Mover socio individual + fix del filtro de roster.
 * Pegar al final de resources/js/app.js.
 * ================================================================== */

let mmSourceSessionId = null;

/** Abre el modal "mover socio" con los socios de la clase origen. */
function openMoveMember(sessionId) {
    mmSourceSessionId = sessionId;
    const sessions = window.SF_SESSIONS || [];
    const source = sessions.find((s) => s.id === sessionId);

    const memberSel = document.getElementById('mm-member');
    const targetSel = document.getElementById('mm-target');
    document.getElementById('mm-warnings').innerHTML = '';

    // Socios de la clase origen.
    memberSel.innerHTML = '';
    if (!source || !source.members.length) {
        memberSel.innerHTML = '<option value="">(esta clase no tiene socios)</option>';
    } else {
        source.members.forEach((m) => {
            memberSel.insertAdjacentHTML('beforeend',
                `<option value="${m.id}">${m.name}</option>`);
        });
    }

    // Clases destino (todas menos la origen).
    targetSel.innerHTML = '';
    sessions.filter((s) => s.id !== sessionId).forEach((s) => {
        targetSel.insertAdjacentHTML('beforeend',
            `<option value="${s.id}">${s.label}</option>`);
    });

    document.getElementById('mm-scope-date').checked = true;
    SF.modal.show('moveMemberModal');
}

async function submitMoveMember() {
    const memberId = document.getElementById('mm-member').value;
    const toSession = document.getElementById('mm-target').value;
    const scope = document.querySelector('input[name="mm-scope"]:checked')?.value || 'date';

    if (!memberId || !toSession) {
        SF.toast('Elige socio y clase destino.', 'error');
        return;
    }

    try {
        const res = await SF.http.post(`/horario/sesiones/${mmSourceSessionId}/socio`, {
            member_id: memberId,
            to_session: toSession,
            scope,
        });
        SF.toast(res.message || 'Socio movido.');
        setTimeout(() => location.reload(), 700);
    } catch (e) {
        SF.toast(e.data?.message || 'No se pudo mover al socio.', 'error');
    }
}

/**
 * Filtro de roster — versión robusta e independiente de SF.
 * Se llama con oninput. Compara contra data-text (o el texto visible).
 */
function filterRoster(input) {
    const term = sfNorm(input.value).trim();
    const list = input.closest('form')?.querySelector('#roster-list')
              || document.getElementById('roster-list');
    if (!list) return;
    list.querySelectorAll('.roster-item').forEach((el) => {
        const text = sfNorm(el.getAttribute('data-text') || el.textContent);
        if (text.includes(term)) {
            el.classList.remove('d-none');
        } else {
            el.classList.add('d-none');
        }
        // el.style.display = text.includes(term) ? '' : 'none';
    });
}

/* ==================================================================
 * DÍA — motor de arrastre del lienzo (estilo Google Calendar).
 * Pegar al final de resources/js/app.js.
 *
 * Usa arrastre por puntero (no HTML5 DnD) para posicionar libre. Al soltar,
 * calcula carril + hora (snap 10 min) y confirma con el endpoint de mover que
 * ya existe (schedule.sessions.move), scope 'date'. La duración no cambia.
 * ================================================================== */

const DC_SNAP_MIN = 10;

function initDayCanvas() {
    // Ambas vistas comparten el mismo motor de arrastre. La diferencia: en la
    // vista de día la fecha es única; en la semanal cada carril lleva su propia
    // fecha (data-date en .dc-lane-body). Por eso la fecha se lee del carril
    // destino al soltar, no del lienzo.
    const canvas = document.querySelector('.day-canvas, .week-canvas');
    if (!canvas) return;

    const pxPerMin = parseFloat(getComputedStyle(canvas).getPropertyValue('--px-per-min')) || 1.2;
    const startMin = parseInt(canvas.dataset.startMin, 10);
    const endMin   = parseInt(canvas.dataset.endMin, 10);

    const events = canvas.querySelectorAll('.dc-event[data-session-id]');
    const laneBodies = canvas.querySelectorAll('.dc-lane-body');

    events.forEach((ev) => makeDraggable(ev, { canvas, pxPerMin, startMin, endMin, laneBodies }));
}

function makeDraggable(ev, ctx) {
    const DRAG_THRESHOLD = 5; // px de movimiento para considerar arrastre

    let armed = false;         // pointer abajo, aún sin decidir click vs drag
    let dragging = false;      // ya superó el umbral → es arrastre
    let ghost = null;          // clon que sigue el puntero
    let placeholder = null;    // bloque fantasma "snapped" dentro del carril destino
    let badge = null;          // etiqueta flotante con la hora destino
    let offsetY = 0;           // desfase puntero→borde superior del evento
    let hDrag = 0;             // altura del evento (fija por duración)
    let downX = 0, downY = 0;  // punto donde bajó el puntero

    // Estado del destino calculado en el último pointermove.
    let target = { lane: null, laneId: null, snapMin: null, date: null };

    ev.addEventListener('pointerdown', (e) => {
        // Solo botón principal; ignora clicks en botones/enlaces internos.
        if (e.button !== 0) return;
        if (e.target.closest('a, button')) return;
        e.preventDefault();

        armed = true;
        dragging = false;
        downX = e.clientX;
        downY = e.clientY;

        const rect = ev.getBoundingClientRect();
        offsetY = e.clientY - rect.top;
        hDrag = rect.height;

        ev.setPointerCapture(e.pointerId);
    });

    ev.addEventListener('pointermove', (e) => {
        if (!armed) return;

        // ¿Ya superó el umbral? Entonces arrancamos el arrastre de verdad.
        if (!dragging) {
            const moved = Math.hypot(e.clientX - downX, e.clientY - downY);
            if (moved < DRAG_THRESHOLD) return;
            startDrag();
        }

        update(e.clientX, e.clientY);
    });

    ev.addEventListener('pointerup', async (e) => {
        if (!armed) return;
        armed = false;

        // No hubo arrastre → fue un CLICK: abrir la hoja de acciones.
        if (!dragging) {
            openSessionActions(ev);
            return;
        }

        dragging = false;
        const hadTarget = target.lane && target.snapMin !== null && target.date;
        const laneId = target.laneId;
        const snapMin = target.snapMin;
        const date = target.date;
        cleanup();

        if (!hadTarget) return; // soltó fuera de un carril

        const hh = String(Math.floor(snapMin / 60)).padStart(2, '0');
        const mm = String(snapMin % 60).padStart(2, '0');
        const startsAt = `${date}T${hh}:${mm}`;

        await commitMove(ev.dataset.sessionId, startsAt, laneId);
    });

    ev.addEventListener('pointercancel', () => {
        armed = false;
        if (dragging) { dragging = false; cleanup(); }
    });

    /* Arranca el arrastre: crea ghost, placeholder y badge. */
    function startDrag() {
        dragging = true;

        ghost = ev.cloneNode(true);
        ghost.classList.add('dc-ghost');
        ghost.style.height = hDrag + 'px';
        ev.classList.add('dc-dragging-origin');
        document.body.appendChild(ghost);

        placeholder = document.createElement('div');
        placeholder.className = 'dc-placeholder';
        placeholder.style.height = hDrag + 'px';

        badge = document.createElement('div');
        badge.className = 'dc-time-badge';
        document.body.appendChild(badge);
    }

    /* Recalcula carril + hora snapped y actualiza ghost, placeholder y badge. */
    function update(x, y) {
        // Ghost sigue el puntero.
        ghost.style.left = (x - ghost.offsetWidth / 2) + 'px';
        ghost.style.top  = (y - offsetY) + 'px';

        // ¿Sobre qué carril está el borde SUPERIOR del bloque arrastrado?
        const topY = y - offsetY;
        const lane = laneUnder(x, topY + 1, ctx.laneBodies) || laneUnder(x, y, ctx.laneBodies);

        ctx.laneBodies.forEach((lb) => lb.classList.remove('dc-lane-hot'));

        if (!lane) {
            target = { lane: null, laneId: null, snapMin: null, date: null };
            if (placeholder.parentNode) placeholder.remove();
            badge.style.display = 'none';
            return;
        }

        lane.classList.add('dc-lane-hot');

        // Minuto crudo por la posición del borde superior dentro del carril.
        const rect = lane.getBoundingClientRect();
        const relY = topY - rect.top;
        let rawMin = ctx.startMin + (relY / ctx.pxPerMin);
        let snapped = Math.round(rawMin / DC_SNAP_MIN) * DC_SNAP_MIN;

        // No dejar que el bloque se salga del lienzo por arriba/abajo.
        const durMin = hDrag / ctx.pxPerMin;
        snapped = Math.max(ctx.startMin, Math.min(snapped, ctx.endMin - durMin));

        target = {
            lane,
            laneId: lane.dataset.laneId || null,
            snapMin: snapped,
            date: lane.dataset.date || null,
        };

        // Colocar el placeholder dentro del carril, en la posición snapped.
        const topPx = (snapped - ctx.startMin) * ctx.pxPerMin;
        placeholder.style.top = topPx + 'px';
        if (placeholder.parentNode !== lane) lane.appendChild(placeholder);

        // Badge con la hora destino, junto al placeholder. Si el destino cae en
        // otro día (vista semanal), anteponemos el día abreviado.
        const hh = String(Math.floor(snapped / 60)).padStart(2, '0');
        const mm = String(snapped % 60).padStart(2, '0');
        const originDate = (ev.dataset.starts || '').slice(0, 10);
        let label = `${hh}:${mm}`;
        if (target.date && target.date !== originDate) {
            label = `${dowLabel(target.date)} ${hh}:${mm}`;
        }
        badge.textContent = label;
        badge.style.display = 'block';
        badge.style.left = (rect.left + 6) + 'px';
        badge.style.top  = (rect.top + topPx - 10) + 'px';
    }

    function cleanup() {
        if (ghost) { ghost.remove(); ghost = null; }
        if (placeholder && placeholder.parentNode) placeholder.remove();
        placeholder = null;
        if (badge) { badge.remove(); badge = null; }
        ev.classList.remove('dc-dragging-origin');
        ctx.laneBodies.forEach((lb) => lb.classList.remove('dc-lane-hot'));
    }
}

/* ==================================================================
 * HOJA DE ACCIONES (click en una clase del lienzo)
 * Un click corto (sin arrastre) abre una hoja inferior con acciones. Cada
 * acción abre el modal/función existente. Reutiliza openMove / openMoveMember.
 * ================================================================== */
let actionSheetEl = null;

/**
 * Renderizador genérico de hoja de acciones.
 *   actions: [{icon,label,fn,danger?,disabled?}]
 *   opts.roster: lista opcional de socios [{socio,name}] que se muestra en una
 *   sección colapsable "Ver alumnos (N)" arriba de las acciones.
 */
function buildActionSheet(title, sub, actions, opts = {}) {
    closeSessionActions();

    const overlay = document.createElement('div');
    overlay.className = 'sheet-overlay';
    overlay.addEventListener('click', (e) => { if (e.target === overlay) closeSessionActions(); });

    const sheet = document.createElement('div');
    sheet.className = 'action-sheet';
    sheet.innerHTML =
        `<div class="action-sheet-head">
            <div class="action-sheet-title"></div>
            <div class="action-sheet-sub mono"></div>
         </div>`;
    sheet.querySelector('.action-sheet-title').textContent = title || '';
    sheet.querySelector('.action-sheet-sub').textContent = sub || '';

    // Sección de alumnos (colapsable).
    if (opts.roster) {
        const roster = opts.roster;
        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'action-sheet-item as-roster-toggle';
        toggle.innerHTML = `<i class="fa-solid fa-users"></i> <span></span> <i class="fa-solid fa-chevron-down as-caret"></i>`;
        toggle.querySelector('span').textContent = `Ver alumnos (${roster.length})`;

        const list = document.createElement('div');
        list.className = 'as-roster-list';
        if (!roster.length) {
            list.innerHTML = `<div class="as-roster-empty">Esta clase no tiene alumnos.</div>`;
        } else {
            roster.forEach((m) => {
                const row = document.createElement('div');
                row.className = 'as-roster-row';
                const num = document.createElement('span');
                num.className = 'as-roster-num mono';
                num.textContent = m.socio ? `#${m.socio}` : '';
                const nm = document.createElement('span');
                nm.className = 'as-roster-name';
                nm.textContent = (m.name || '—') + (m.age != null ? ` · ${m.age} a` : '');
                row.appendChild(num); row.appendChild(nm);
                list.appendChild(row);
            });
        }
        toggle.addEventListener('click', () => {
            const open = sheet.classList.toggle('as-roster-open');
            toggle.querySelector('.as-caret').style.transform = open ? 'rotate(180deg)' : '';
        });
        sheet.appendChild(toggle);
        sheet.appendChild(list);
    }

    (actions.length ? actions : [{ icon: 'fa-circle-info', label: 'Sin acciones disponibles', disabled: true }])
        .forEach((a) => {
            const btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'action-sheet-item' + (a.danger ? ' is-danger' : '') + (a.disabled ? ' is-disabled' : '');
            btn.innerHTML = `<i class="fa-solid ${a.icon}"></i> <span></span>`;
            btn.querySelector('span').textContent = a.label;
            if (!a.disabled && a.fn) btn.addEventListener('click', a.fn);
            sheet.appendChild(btn);
        });

    const cancel = document.createElement('button');
    cancel.type = 'button';
    cancel.className = 'action-sheet-cancel';
    cancel.textContent = 'Cerrar';
    cancel.addEventListener('click', closeSessionActions);
    sheet.appendChild(cancel);

    overlay.appendChild(sheet);
    document.body.appendChild(overlay);
    actionSheetEl = overlay;
    requestAnimationFrame(() => overlay.classList.add('is-open'));
    document.addEventListener('keydown', escCloseSheet);
}

/* ==================================================================
 * POPOVER anclado (reemplaza la hoja de acciones inferior).
 * Se abre junto a la clase/slot clicado, muestra el roster (nombres) y las
 * acciones. Un popover a la vez; cierra con click afuera, Esc o scroll.
 * ================================================================== */
let popoverEl = null;

function escClosePopover(e) { if (e.key === 'Escape') closePopover(); }

function outsideClosePopover(e) {
    if (popoverEl && !popoverEl.contains(e.target)) closePopover();
}

function closePopover() {
    if (!popoverEl) return;
    document.removeEventListener('keydown', escClosePopover);
    document.removeEventListener('click', outsideClosePopover, true);
    window.removeEventListener('scroll', closePopover, true);
    window.removeEventListener('resize', closePopover);
    const el = popoverEl;
    popoverEl = null;
    el.classList.remove('is-open');
    setTimeout(() => el.remove(), 140);
}

/** Coloca el popover junto al ancla, con volteo y recorte al viewport. */
function placePopover(pop, anchor) {
    const a = anchor.getBoundingClientRect();
    const pw = pop.offsetWidth;
    const ph = pop.offsetHeight;
    const gap = 8;

    let left = a.right + gap;                       // preferimos a la derecha
    if (left + pw > window.innerWidth - 8) left = a.left - gap - pw; // si no cabe, a la izquierda
    if (left < 8) left = Math.max(8, Math.min(a.left, window.innerWidth - pw - 8));

    let top = a.top;
    if (top + ph > window.innerHeight - 8) top = window.innerHeight - ph - 8;
    if (top < 8) top = 8;

    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
}

/**
 * Construye y muestra el popover.
 *   actions: [{icon,label,fn,danger?,disabled?}]
 *   opts.roster: lista [{socio,name}] que se lista arriba de las acciones.
 */
function buildPopover(anchor, title, sub, actions, opts = {}) {
    closePopover();

    const pop = document.createElement('div');
    pop.className = 'sf-pop';

    const head = document.createElement('div');
    head.className = 'sf-pop-head';
    const h = document.createElement('div'); h.className = 'sf-pop-title'; h.textContent = title || '';
    const s = document.createElement('div'); s.className = 'sf-pop-sub mono'; s.textContent = sub || '';
    head.appendChild(h); head.appendChild(s);
    pop.appendChild(head);

    if (opts.roster) {
        const roster = opts.roster;
        const rh = document.createElement('div');
        rh.className = 'sf-pop-roster-head';
        rh.innerHTML = `<i class="fa-solid fa-users"></i> Alumnos (${roster.length})`;
        pop.appendChild(rh);

        const list = document.createElement('div');
        list.className = 'sf-pop-roster';
        if (!roster.length) {
            list.innerHTML = `<div class="sf-pop-empty">Esta clase no tiene alumnos.</div>`;
        } else {
            roster.forEach((m) => {
                const row = document.createElement('div');
                row.className = 'sf-pop-row';
                const num = document.createElement('span'); num.className = 'sf-pop-num mono';
                num.textContent = m.socio ? `#${m.socio}` : '';
                const nm = document.createElement('span'); nm.className = 'sf-pop-name';
                nm.textContent = (m.name || '—') + (m.age != null ? ` · ${m.age} a` : '');
                row.appendChild(num); row.appendChild(nm);
                list.appendChild(row);
            });
        }
        pop.appendChild(list);
    }

    const acts = actions && actions.length ? actions
        : [{ icon: 'fa-circle-info', label: 'Sin acciones disponibles', disabled: true }];
    const ac = document.createElement('div');
    ac.className = 'sf-pop-actions';
    acts.forEach((a) => {
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'sf-pop-item' + (a.danger ? ' is-danger' : '') + (a.disabled ? ' is-disabled' : '');
        btn.innerHTML = `<i class="fa-solid ${a.icon}"></i> <span></span>`;
        btn.querySelector('span').textContent = a.label;
        if (!a.disabled && a.fn) btn.addEventListener('click', a.fn);
        ac.appendChild(btn);
    });
    pop.appendChild(ac);

    document.body.appendChild(pop);
    popoverEl = pop;
    placePopover(pop, anchor);
    requestAnimationFrame(() => pop.classList.add('is-open'));

    // Diferir el listener de "click afuera" para no cerrarlo con el click que lo abrió.
    setTimeout(() => document.addEventListener('click', outsideClosePopover, true), 0);
    document.addEventListener('keydown', escClosePopover);
    window.addEventListener('scroll', closePopover, true);
    window.addEventListener('resize', closePopover);
}

function openSessionActions(cardEl) {
    const title = cardEl.querySelector('.dc-event-title')?.textContent?.trim() || 'Clase';
    const time  = cardEl.querySelector('.dc-event-time')?.textContent?.trim() || '';
    const sessionId = cardEl.dataset.sessionId;

    // ¿El usuario puede editar? (modales presentes = tiene permiso move-classes)
    const canMove = !!document.getElementById('moveModal');
    const canMoveMember = !!document.getElementById('moveMemberModal');

    const actions = [];
    if (canMove) {
        actions.push({ icon: 'fa-arrows-up-down-left-right', label: 'Mover clase (fecha, carril, hora)', fn: () => { closePopover(); SF.openMove(cardEl); } });
        actions.push({ icon: 'fa-user-pen', label: 'Cambiar instructor', fn: () => { closePopover(); SF.openMove(cardEl); setTimeout(() => document.getElementById('move-instructor')?.focus(), 300); } });
        actions.push({ icon: 'fa-user-group', label: 'Segundo maestro (co-maestro)', fn: () => { closePopover(); SF.openMove(cardEl); setTimeout(() => document.getElementById('move-instructor-2')?.focus(), 300); } });
    }
    if (canMoveMember) {
        actions.push({ icon: 'fa-user-group', label: 'Mover un socio de esta clase', fn: () => { closePopover(); SF.openMoveMember(sessionId); } });
    }
    if (canMove) {
        actions.push({ icon: 'fa-ban', label: 'Cancelar clase', danger: true, fn: () => { closePopover(); cancelSessionById(sessionId); } });
    }
    if (!actions.length) {
        actions.push({ icon: 'fa-circle-info', label: 'No tienes permisos para editar clases', disabled: true });
    }

    // Roster de la clase (desde el payload ya serializado en la página).
    const sess = (window.SF_SESSIONS || []).find((s) => String(s.id) === String(sessionId));
    const roster = sess ? sess.members : [];

    buildPopover(cardEl, title, time, actions, { roster });
}

/* ---- Plantilla: hoja de acciones para un slot ---- */

function openSlotActions(cardEl) {
    const d = cardEl.dataset;
    const title = d.programName || 'Clase';
    const sub = `${d.start || ''} · ${d.duration || ''}′`;

    const actions = [
        { icon: 'fa-pen', label: 'Editar clase (programa, día, hora…)', fn: () => { closePopover(); openSlotEdit(d); } },
        { icon: 'fa-user-group', label: 'Editar roster', fn: () => { closePopover(); window.location.href = d.rosterUrl; } },
        { icon: 'fa-trash', label: 'Quitar del horario base', danger: true, fn: () => { closePopover(); deleteSlot(d.destroyUrl); } },
    ];

    buildPopover(cardEl, title, sub, actions);
}

/** Prefill del modal en modo edición (PUT al slot). */
function openSlotEdit(d) {
    const form = document.getElementById('slotForm');
    if (!form) return;

    form.action = d.updateUrl;
    document.getElementById('slot-method').value = 'PUT';
    document.getElementById('slotModalTitle').textContent = 'Editar clase';
    document.getElementById('slotSubmitBtn').textContent = 'Guardar';

    document.getElementById('slot-program').value    = d.program || '';
    syncLevelField('slot-program', 'slot-level', 'slot-level-wrap', d.levelId || '');
    document.getElementById('slot-weekday').value    = d.weekday || '';
    document.getElementById('slot-start').value      = d.start || '';
    document.getElementById('slot-lane').value       = d.lane || '';
    document.getElementById('slot-instructor').value = d.instructor || '';
    const si2 = document.getElementById('slot-instructor-2'); if (si2) si2.value = d.instructor2 || '';
    document.getElementById('slot-duration').value   = d.duration || '';

    // Roster: marcar los socios actuales de la clase.
    setSlotMembers((d.rosterIds || '').split(',').filter(Boolean));

    SF.modal.show('slotModal');
}

/** Reset del modal a modo alta (POST store). */
function openSlotAdd() {
    const form = document.getElementById('slotForm');
    if (form) {
        form.action = form.dataset.storeUrl;
        document.getElementById('slot-method').value = 'POST';
        document.getElementById('slotModalTitle').textContent = 'Agregar clase';
        document.getElementById('slotSubmitBtn').textContent = 'Agregar';
        document.getElementById('slot-start').value = '';
        document.getElementById('slot-duration').value = '';
        // program/weekday/lane/instructor quedan en su primer valor por defecto.
        document.getElementById('slot-lane').value = '';
        document.getElementById('slot-instructor').value = '';
        const si2 = document.getElementById('slot-instructor-2'); if (si2) si2.value = '';
        syncLevelField('slot-program', 'slot-level', 'slot-level-wrap', '');
        setSlotMembers([]); // sin socios por defecto
    }
    SF.modal.show('slotModal');
}

/* --- Picker de socios dentro del modal de clase --- */
function setSlotMembers(ids) {
    const set = new Set((ids || []).map(String));
    document.querySelectorAll('#slot-members input[type="checkbox"]').forEach((cb) => {
        cb.checked = set.has(String(cb.value));
    });
    updateSlotRosterCount();
}
function filterSlotMembers(input) {
    const term = (input.value || '').trim().toLowerCase();
    document.querySelectorAll('#slot-members .roster-item').forEach((el) => {
        el.style.display = (el.getAttribute('data-text') || '').includes(term) ? '' : 'none';
    });
}
function updateSlotRosterCount() {
    const n = document.querySelectorAll('#slot-members input:checked').length;
    const el = document.getElementById('slot-roster-count');
    if (el) el.textContent = n;
}
Object.assign(window.SF, { filterSlotMembers, updateSlotRosterCount });

/** Enviar el form oculto de borrado al endpoint del slot. */
function deleteSlot(destroyUrl) {
    if (!confirm('¿Quitar esta clase del horario base?')) return;
    const f = document.getElementById('slotDeleteForm');
    if (!f) return;
    f.action = destroyUrl;
    f.submit();
}

function escCloseSheet(e) { if (e.key === 'Escape') closeSessionActions(); }

function closeSessionActions() {
    if (!actionSheetEl) return;
    document.removeEventListener('keydown', escCloseSheet);
    const el = actionSheetEl;
    actionSheetEl = null;
    el.classList.remove('is-open');
    setTimeout(() => el.remove(), 180);
}

/** Cancelar directamente por id (usa el endpoint existente). */
async function cancelSessionById(sessionId) {
    if (!confirm('¿Cancelar esta clase?')) return;
    try {
        const res = await SF.http.post(`/horario/sesiones/${sessionId}/cancelar`, { notes: null });
        SF.toast(res.message || 'Clase cancelada.');
        setTimeout(() => location.reload(), 700);
    } catch (e) {
        SF.toast('No se pudo cancelar.', 'error');
    }
}

/* ==================================================================
 * ASISTENCIA MENSUAL — toggle de celda
 * Cicla: vacío → present → absent → excused → vacío. Escribe al backend.
 * ================================================================== */
const ATT_CYCLE = { '': 'present', 'present': 'absent', 'absent': 'excused', 'excused': '' };
const ATT_MARK  = { 'present': 'P', 'absent': 'F', 'excused': 'J', '': '' };

async function toggleAttendanceCell(cell) {
    const sessionId = cell.dataset.session;
    const memberId  = cell.dataset.member;
    const current   = cell.dataset.status || '';
    const next      = ATT_CYCLE[current] ?? 'present';

    // Optimista: pinta ya; si falla, revierte.
    applyCellStatus(cell, next);

    try {
        const res = await SF.http.post(`/asistencia/celda/${sessionId}`, {
            member_id: memberId,
            status: next || null,
        });
        applyCellStatus(cell, res.status || '');
    } catch (e) {
        applyCellStatus(cell, current); // revertir
        SF.toast('No se pudo guardar la asistencia.', 'error');
    }
}

function applyCellStatus(cell, status) {
    cell.classList.remove('att-present', 'att-absent', 'att-excused');
    if (status) cell.classList.add('att-' + status);
    cell.dataset.status = status;
    const mark = cell.querySelector('.att-mark');
    if (mark) mark.textContent = ATT_MARK[status] ?? '';
}

/** Etiqueta de día abreviada (es) a partir de 'YYYY-MM-DD'. */
function dowLabel(isoDate) {
    const dias = ['Dom', 'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb'];
    const d = new Date(isoDate + 'T00:00:00');
    return dias[d.getDay()] || '';
}

/** ¿Qué cuerpo de carril está bajo estas coordenadas? */
function laneUnder(x, y, laneBodies) {
    for (const lb of laneBodies) {
        const r = lb.getBoundingClientRect();
        if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return lb;
    }
    return null;
}

/** Confirma el movimiento con el endpoint existente (scope date). */
async function commitMove(sessionId, startsAt, laneId) {
    try {
        const res = await SF.http.post(`/horario/sesiones/${sessionId}/mover`, {
            scope: 'date',
            starts_at: startsAt,
            lane_id: laneId,
        });
        if (res.warnings && res.warnings.length) {
            res.warnings.forEach((w) => SF.toast(w, 'error'));
        }
        SF.toast(res.message || 'Clase movida.');
        setTimeout(() => location.reload(), 650);
    } catch (e) {
        SF.toast(e.data?.message || 'No se pudo mover la clase.', 'error');
    }
}

document.addEventListener('DOMContentLoaded', initDayCanvas);
Object.assign(window.SF, { initDayCanvas, openSessionActions, closeSessionActions, closePopover, openSlotActions, openSlotEdit, openSlotAdd, toggleAttendanceCell });


/* ==================================================================
 * SELECTOR DE CLASES (inscripción de socios)
 * En el alta de socio: al elegir tipo de socio muestra solo las clases de su
 * programa y pre-marca una sugerencia según los días/semana del tipo.
 * ================================================================== */

// Sugerencia de días (ISO) según días/semana del tipo de socio.
const ENROLL_PATTERN = { 1: [3], 2: [2, 4], 3: [1, 3, 5], 4: [1, 2, 3, 4], 5: [1, 2, 3, 4, 5] };

function initSlotPicker() {
    const picker = document.querySelector('.slot-picker');
    if (!picker) return;

    // Estado visual de cada chip al marcar/desmarcar.
    picker.addEventListener('change', (e) => {
        const cb = e.target.closest('input[type="checkbox"]');
        if (cb) cb.closest('.slot-chip')?.classList.toggle('is-checked', cb.checked);
    });

    if (picker.dataset.mode !== 'create') return;

    const sel = document.getElementById('membership_type_id');
    if (!sel) return;
    sel.addEventListener('change', () => applyTypeToPicker(picker, sel));
    if (sel.value) applyTypeToPicker(picker, sel); // tipo ya elegido (old input)
}

function applyTypeToPicker(picker, sel) {
    const opt  = sel.options[sel.selectedIndex];
    const prog = opt?.dataset.program || '';
    const days = parseInt(opt?.dataset.days || '0', 10);
    const hint = document.getElementById('slot-picker-hint');

    let shown = null;
    picker.querySelectorAll('.slot-group').forEach((g) => {
        const match = prog && g.dataset.programId === prog;
        g.classList.toggle('d-none', !match);
        if (match) shown = g;
        // Al cambiar de tipo, limpiar marcas de todos los grupos.
        g.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
            cb.checked = false;
            cb.closest('.slot-chip')?.classList.remove('is-checked');
        });
    });

    if (!prog) { if (hint) hint.textContent = 'Elige un tipo de socio para ver y sugerir sus clases.'; return; }
    if (!shown) { if (hint) hint.textContent = 'No hay clases de ese programa en el horario base.'; return; }

    // Pre-marcar la clase más temprana de cada día sugerido.
    const pattern = ENROLL_PATTERN[days] || [];
    pattern.forEach((wd) => {
        const chips = [...shown.querySelectorAll('.slot-chip')]
            .filter((c) => parseInt(c.dataset.weekday, 10) === wd)
            .sort((a, b) => (a.dataset.start > b.dataset.start ? 1 : -1));
        const first = chips[0];
        if (first) { first.querySelector('input').checked = true; first.classList.add('is-checked'); }
    });

    if (hint) {
        hint.textContent = days
            ? `Sugerencia para ${days} día(s)/semana. Ajusta las que haga falta.`
            : 'Marca las clases del socio.';
    }
}

document.addEventListener('DOMContentLoaded', initSlotPicker);
Object.assign(window.SF, { initSlotPicker });


/* ==================================================================
 * PANEL DE SOCIOS del calendario — filtro + arrastrar a una clase.
 * Arrastrar un socio (HTML5 drag) y soltarlo sobre una clase (.dc-event) lo
 * inscribe, preguntando el alcance (serie / solo este día). Usa el endpoint
 * existente schedule.sessions.add-member.
 * ================================================================== */

function filterMemberPanel(input) {
    const term = sfNorm(input.value).trim();
    document.querySelectorAll('#mpList .mp-member').forEach((el) => {
        el.style.display = sfNorm(el.dataset.text).includes(term) ? '' : 'none';
    });
}

let mpDropHot = null;
function mpHighlight(ev) {
    if (mpDropHot === ev) return;
    mpClearHighlight();
    mpDropHot = ev;
    ev.classList.add('mp-drop-hot');
}
function mpClearHighlight() {
    if (mpDropHot) { mpDropHot.classList.remove('mp-drop-hot'); mpDropHot = null; }
}

function initMemberDrag() {
    const chips = document.querySelectorAll('.mp-member[draggable="true"]');
    const canvas = document.querySelector('.cal');
    if (!chips.length || !canvas) return;

    let draggingId = null;

    chips.forEach((m) => {
        m.addEventListener('dragstart', (e) => {
            draggingId = m.dataset.memberId;
            e.dataTransfer.setData('text/plain', draggingId);
            e.dataTransfer.effectAllowed = 'copy';
            m.classList.add('is-dragging');
            document.body.classList.add('mp-dragging');
        });
        m.addEventListener('dragend', () => {
            m.classList.remove('is-dragging');
            document.body.classList.remove('mp-dragging');
            mpClearHighlight();
        });
    });

    canvas.addEventListener('dragover', (e) => {
        const ev = e.target.closest('.dc-event');
        if (!ev) { mpClearHighlight(); return; }
        e.preventDefault();
        e.dataTransfer.dropEffect = 'copy';
        mpHighlight(ev);
    });
    canvas.addEventListener('drop', (e) => {
        const ev = e.target.closest('.dc-event');
        mpClearHighlight();
        if (!ev) return;
        e.preventDefault();
        const memberId = e.dataTransfer.getData('text/plain') || draggingId;
        if (memberId) askEnrollScope(ev, memberId);
    });
}

/** Pregunta el alcance (serie / sólo este día) y luego inscribe. */
function askEnrollScope(ev, memberId) {
    const sub = (ev.querySelector('.dc-event-title')?.textContent?.trim() || 'Clase')
        + ' · ' + (ev.querySelector('.dc-event-time')?.textContent?.trim() || '');
    const sessionId = ev.dataset.sessionId;
    buildPopover(ev, 'Inscribir socio', sub, [
        { icon: 'fa-repeat',        label: 'Toda la serie (cada semana)', fn: () => { closePopover(); enrollMemberToSession(sessionId, memberId, 'series'); } },
        { icon: 'fa-calendar-day',  label: 'Sólo este día',               fn: () => { closePopover(); enrollMemberToSession(sessionId, memberId, 'date'); } },
    ]);
}

async function enrollMemberToSession(sessionId, memberId, scope) {
    try {
        const res = await SF.http.post(`/horario/sesiones/${sessionId}/socio/agregar`, {
            member_id: memberId, scope,
        });
        SF.toast(res.message || 'Socio inscrito.');
        setTimeout(() => location.reload(), 650);
    } catch (e) {
        SF.toast(e.data?.message || 'No se pudo inscribir al socio.', 'error');
    }
}

document.addEventListener('DOMContentLoaded', initMemberDrag);
Object.assign(window.SF, { filterMemberPanel, initMemberDrag });


/* ==================================================================
 * Búsqueda de socios sin distinguir acentos + alta rápida de clase.
 * ================================================================== */

/** Normaliza: minúsculas y sin acentos ("García" -> "garcia"). */
const sfNorm = (s) => (s || '').toString().normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

/** Filtro genérico de una lista de .roster-item (checkboxes de socios). */
function filterChecklist(input, listSelector) {
    const term = sfNorm(input.value).trim();
    document.querySelectorAll(`${listSelector} .roster-item`).forEach((el) => {
        el.style.display = sfNorm(el.getAttribute('data-text')).includes(term) ? '' : 'none';
    });
}
function updateChecklistCount(listSelector, countSelector) {
    const n = document.querySelectorAll(`${listSelector} input:checked`).length;
    const el = document.querySelector(countSelector);
    if (el) el.textContent = n;
}

/** Muestra/llena el <select> de nivel según el programa elegido.
 *  Usa window.SF_PROGRAM_LEVELS = { programId: [{id,name,duration}] }. */
function syncLevelField(progSelId, levelSelId, wrapId, selectedId = '') {
    const prog = document.getElementById(progSelId);
    const sel  = document.getElementById(levelSelId);
    const wrap = document.getElementById(wrapId);
    if (!prog || !sel || !wrap) return;

    const levels = (window.SF_PROGRAM_LEVELS || {})[prog.value] || [];
    if (!levels.length) {
        wrap.classList.add('d-none');
        sel.innerHTML = '<option value="">— Sin nivel —</option>';
        sel.value = '';
        return;
    }
    wrap.classList.remove('d-none');
    sel.innerHTML = '<option value="">— Sin nivel —</option>'
        + levels.map((l) => `<option value="${l.id}" data-duration="${l.duration}">${l.name} (${l.duration}′)</option>`).join('');
    sel.value = selectedId || '';
}

function initLevelSelects() {
    const qp = document.getElementById('qa-program');
    if (qp) {
        qp.addEventListener('change', () => syncLevelField('qa-program', 'qa-level', 'qa-level-wrap'));
        syncLevelField('qa-program', 'qa-level', 'qa-level-wrap');
    }
    const sp = document.getElementById('slot-program');
    if (sp) {
        sp.addEventListener('change', () => syncLevelField('slot-program', 'slot-level', 'slot-level-wrap'));
    }
}
document.addEventListener('DOMContentLoaded', initLevelSelects);
Object.assign(window.SF, { syncLevelField });

const QA_SNAP = 15; // minutos

function initQuickAdd() {
    const modalEl = document.getElementById('quickAddModal');
    const canvas = document.querySelector('.cal');
    if (!modalEl || !canvas) return;

    const pxPerMin = parseFloat(getComputedStyle(canvas).getPropertyValue('--px-per-min')) || 1.6;
    const startMin = parseInt(canvas.dataset.startMin, 10);

    canvas.querySelectorAll('.cal-col').forEach((col) => {
        col.style.cursor = 'copy';
        col.addEventListener('click', (e) => {
            if (e.target.closest('.dc-event')) return; // clic sobre una clase: su propio manejador
            const rect = col.getBoundingClientRect();
            let min = startMin + (e.clientY - rect.top) / pxPerMin;
            min = Math.round(min / QA_SNAP) * QA_SNAP;
            min = Math.max(startMin, min);
            openQuickAdd(col.dataset.date || '', min, col.dataset.laneId || '');
        });
    });
}

const DOW_ES = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];

function openQuickAdd(date, minutes, laneId) {
    const hh = String(Math.floor(minutes / 60)).padStart(2, '0');
    const mm = String(minutes % 60).padStart(2, '0');

    document.getElementById('qa-date').value = date;
    document.getElementById('qa-time').value = `${hh}:${mm}`;
    const laneSel = document.getElementById('qa-lane');
    if (laneSel) laneSel.value = laneId || '';
    document.getElementById('qa-instructor').value = '';
    const qi2 = document.getElementById('qa-instructor-2'); if (qi2) qi2.value = '';
    document.getElementById('qa-scope-weekly').checked = true;
    syncLevelField('qa-program', 'qa-level', 'qa-level-wrap', '');
    document.querySelectorAll('#qa-members input[type="checkbox"]').forEach((cb) => { cb.checked = false; });
    updateChecklistCount('#qa-members', '#qa-roster-count');

    const ctx = document.getElementById('qa-context');
    if (ctx) {
        let label = '';
        if (date) {
            const d = new Date(date + 'T00:00:00');
            const dow = DOW_ES[d.getDay()] || '';
            label = dow.charAt(0).toUpperCase() + dow.slice(1)
                + ' ' + String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0');
        }
        const laneTxt = laneSel && laneSel.value
            ? laneSel.options[laneSel.selectedIndex].textContent.trim()
            : 'Sin carril';
        ctx.textContent = `${label} · ${laneTxt} · ${hh}:${mm}`;
    }

    SF.modal.show('quickAddModal');
}

document.addEventListener('DOMContentLoaded', initQuickAdd);
Object.assign(window.SF, {
    filterChecklist, updateChecklistCount, initQuickAdd, openQuickAdd,
    // Accent-insensitive para el modal de plantilla (reemplaza las versiones previas).
    filterSlotMembers: (input) => filterChecklist(input, '#slot-members'),
    updateSlotRosterCount: () => updateChecklistCount('#slot-members', '#slot-roster-count'),
});


Object.assign(window.SF, { openMoveMember, submitMoveMember, filterRoster });


Object.assign(window.SF, { initScheduleDnD });

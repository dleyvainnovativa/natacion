<!DOCTYPE html>
<html lang="es" data-theme="{{ request()->cookie('sf-theme', 'light') }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Ingresar — Swim Fitness</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    @vite(['resources/css/theme.css'])
</head>
<body class="d-flex align-items-center justify-content-center" style="min-height:100vh">
    <div class="app-card p-4" style="width:100%;max-width:380px">
        <div class="text-center mb-4">
            <i class="fa-solid fa-water fs-2" style="color:var(--brand-teal)"></i>
            <h1 class="h4 mt-2 mb-0">Swim Fitness</h1>
            <p class="text-muted small">Panel de gestión</p>
        </div>

        @if ($errors->any())
            <div class="alert alert-danger py-2 small">{{ $errors->first() }}</div>
        @endif

        <form method="POST" action="{{ route('login.attempt') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label small">Correo</label>
                <input type="email" name="email" class="form-control" value="{{ old('email') }}" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label small">Contraseña</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button class="btn btn-brand w-100">Ingresar</button>
        </form>
    </div>
</body>
</html>

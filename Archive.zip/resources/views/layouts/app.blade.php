<!DOCTYPE html>
{{-- Lee la cookie de tema en el primer render para evitar parpadeo. --}}
<html lang="es" data-theme="{{ request()->cookie('sf-theme', 'light') }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Swim Fitness')</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
    @vite(['resources/css/theme.css', 'resources/js/app.js'])
</head>

<body>
    <div class="app-shell">
        <aside class="app-sidebar">
            <div class="d-flex align-items-center gap-2 mb-4">
                <i class="fa-solid fa-water fs-4" style="color: var(--brand-teal)"></i>
                <strong>Swim Fitness</strong>
            </div>

            <nav class="d-flex flex-column gap-1">
                {{-- Todos ven el horario --}}
                <a href="{{ route('schedule.index') }}"
                    class="app-nav-link {{ request()->routeIs('schedule.*') ? 'active' : '' }}">
                    <i class="fa-regular fa-calendar-days"></i> Horario
                </a>

                @can('manage-members')
                <a href="{{ route('members.index') }}"
                    class="app-nav-link {{ request()->routeIs('members.*') ? 'active' : '' }}">
                    <i class="fa-regular fa-id-card"></i> Socios
                </a>
                @endcan

                @can('mark-member-attendance')
                <a href="#" class="app-nav-link">
                    <i class="fa-solid fa-user-check"></i> Asistencia alumnos
                </a>
                @endcan

                @can('mark-instructor-attendance')
                <a href="#" class="app-nav-link">
                    <i class="fa-solid fa-clipboard-user"></i> Asistencia instructores
                </a>
                @endcan

                @can('view-reports')
                <a href="#" class="app-nav-link">
                    <i class="fa-solid fa-chart-line"></i> Reportes
                </a>
                @endcan

                @can('mark-member-attendance')
                <a href="{{ route('attendance.members.index') }}"
                    class="app-nav-link {{ request()->routeIs('attendance.members.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-user-check"></i> Asistencia alumnos
                </a>
                @endcan

                @can('mark-instructor-attendance')
                <a href="{{ route('attendance.instructors.index') }}"
                    class="app-nav-link {{ request()->routeIs('attendance.instructors.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-clipboard-user"></i> Asistencia instructores
                </a>
                @endcan

                @can('view-reports')
                <a href="{{ route('reports.index') }}"
                    class="app-nav-link {{ request()->routeIs('reports.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-chart-line"></i> Reportes
                </a>
                @endcan

                @can('record-payments')
                <a href="{{ route('payments.index') }}"
                    class="app-nav-link {{ request()->routeIs('payments.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-money-bill-wave"></i> Cobros
                </a>
                @endcan
                @can('manage-maintenance')
                <a href="{{ route('maintenance.index') }}"
                    class="app-nav-link {{ request()->routeIs('maintenance.*') ? 'active' : '' }}">
                    <i class="fa-solid fa-wrench"></i> Mantenimiento
                </a>
                @endcan

            </nav>

            <hr class="my-3" style="border-color: var(--border)">

            <div class="small text-muted mb-2">
                {{ auth()->user()->name }}
                <span class="badge-role ms-1">{{ auth()->user()->role->label() }}</span>
            </div>
            <div class="d-flex gap-2">
                <button class="btn btn-sm btn-outline-secondary" data-theme-toggle title="Cambiar tema">
                    <i class="fa-solid fa-circle-half-stroke"></i>
                </button>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn btn-sm btn-outline-secondary">
                        <i class="fa-solid fa-arrow-right-from-bracket"></i> Salir
                    </button>
                </form>
            </div>
        </aside>

        <main class="app-main">
            @yield('content')
        </main>
    </div>

    <div id="toast-root" aria-live="polite" aria-atomic="true"></div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>
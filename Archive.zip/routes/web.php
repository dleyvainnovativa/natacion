<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\MaintenanceController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\MemberImportController;
use App\Http\Controllers\ScheduleController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\SlotController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReportController;
use App\Http\Controllers\PaymentController;

// --- Invitado ---
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'show'])->name('login');
    Route::post('/login', [AuthController::class, 'attempt'])->name('login.attempt');
});

// --- Autenticado ---
Route::middleware('auth')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

    Route::redirect('/', '/horario');

    // Horario: todos los roles autenticados pueden ver.
    Route::get('/horario', [ScheduleController::class, 'index'])->name('schedule.index');

    // Socios: admin, coordinador, recepción (Gate manage-members en T1).
    Route::get('/socios', [MemberController::class, 'index'])
        ->middleware('role:admin,coordinator,receptionist')
        ->name('members.index');

    // Rutas de T2+ (mover clases, asistencia, reportes) se agregan por fase.
    // Importar: solo admin (Gate import-members). Debe ir ANTES del resource
    // para que /socios/importar no choque con /socios/{member}.
    Route::get('/socios/importar', [MemberImportController::class, 'show'])
        ->name('members.import.show');
    Route::post('/socios/importar', [MemberImportController::class, 'store'])
        ->name('members.import.store');

    // CRUD de socios: admin, coordinador, recepción.
    Route::resource('socios', MemberController::class)
        ->parameters(['socios' => 'member'])
        ->names('members')
        ->middleware('role:admin,coordinator,receptionist');
});

// Ver horario: todos los roles autenticados.
Route::get('/horario', [ScheduleController::class, 'index'])->name('schedule.index');

// Todo lo demás requiere permiso para mover clases (recepción/coord/admin).
Route::middleware('role:admin,coordinator,receptionist')->group(function () {
    // Plantilla recurrente
    Route::get('/horario/plantilla', [ScheduleController::class, 'template'])->name('schedule.template');

    Route::post('/horario/slots', [SlotController::class, 'store'])->name('schedule.slots.store');
    Route::put('/horario/slots/{slot}', [SlotController::class, 'update'])->name('schedule.slots.update');
    Route::delete('/horario/slots/{slot}', [SlotController::class, 'destroy'])->name('schedule.slots.destroy');

    // Roster del slot
    Route::get('/horario/slots/{slot}/roster', [SlotController::class, 'roster'])->name('schedule.slots.roster');
    Route::put('/horario/slots/{slot}/roster', [SlotController::class, 'updateRoster'])->name('schedule.slots.roster.update');

    // Sesiones fechadas (JSON): mover / cancelar / previsualizar conflictos
    Route::post('/horario/sesiones/{session}/mover', [SessionController::class, 'move'])->name('schedule.sessions.move');
    Route::post('/horario/sesiones/{session}/cancelar', [SessionController::class, 'cancel'])->name('schedule.sessions.cancel');
    Route::post('/horario/sesiones/{session}/conflictos', [SessionController::class, 'checkConflicts'])->name('schedule.sessions.conflicts');
});


Route::middleware('role:admin')->group(function () {
    Route::get('/reportes', fn() => view('reports.index'))->name('reports.index');

    Route::get('/reportes/pago-instructores', [ReportController::class, 'payroll'])
        ->name('reports.payroll');

    Route::get('/reportes/control-socios', [ReportController::class, 'memberControl'])
        ->name('reports.member-control');
});


Route::middleware('role:admin,receptionist')->group(function () {
    // Registro general de cobros + vencidos (rutas específicas ANTES de las
    // que llevan {member}, para que /pagos/vencidos no se confunda).
    Route::get('/pagos', [PaymentController::class, 'index'])->name('payments.index');
    Route::get('/pagos/vencidos', [PaymentController::class, 'overdue'])->name('payments.overdue');

    // Historial y registro por socio.
    Route::get('/pagos/socio/{member}', [PaymentController::class, 'member'])->name('payments.member');
    Route::post('/pagos/socio/{member}', [PaymentController::class, 'store'])->name('payments.store');
});

Route::middleware('role:admin,coordinator')->group(function () {
    Route::get('/mantenimiento', [MaintenanceController::class, 'index'])->name('maintenance.index');
    Route::post('/mantenimiento', [MaintenanceController::class, 'store'])->name('maintenance.store');
    Route::put('/mantenimiento/{maintenance}', [MaintenanceController::class, 'update'])->name('maintenance.update');
    Route::patch('/mantenimiento/{maintenance}/toggle', [MaintenanceController::class, 'toggle'])->name('maintenance.toggle');
    Route::delete('/mantenimiento/{maintenance}', [MaintenanceController::class, 'destroy'])->name('maintenance.destroy');
});
